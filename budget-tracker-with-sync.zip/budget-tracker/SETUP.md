# Budget Tracker Setup Guide
## Total time: ~30–45 minutes, no coding required

---

## Step 1 — Set up Supabase (your database)

1. Go to **supabase.com** and create a free account
2. Click **"New project"** → give it a name like `budget-tracker` → set a password → click Create
3. Wait ~2 minutes for it to provision
4. In the left sidebar, click **"SQL Editor"** → **"New query"**
5. Open the file `supabase-setup.sql` from this folder, copy everything, paste it in, and click **"Run"**
6. You should see "Success. No rows returned"

Now grab your keys:
7. Go to **Settings → API** in the left sidebar
8. Copy these two values — you'll need them in Step 3:
   - **Project URL** (looks like `https://xxxx.supabase.co`)
   - **service_role** key (under "Project API keys" — use service_role, NOT anon)

---

## Step 2 — Set up Plaid (your bank connection)

1. Go to **dashboard.plaid.com** and create a free account
2. After signing in, your dashboard will show your keys immediately
3. Copy these two values:
   - **Client ID**
   - **Sandbox secret** (for testing) or **Development secret** (for real banks)

> **Note:** To connect real bank accounts, click "Request Development access" on the Plaid dashboard. It's free and usually approved within a day or two. For now you can test with Sandbox.

---

## Step 3 — Add your secret keys to Netlify

1. Go to your **Netlify dashboard** → click your site → **Site configuration** → **Environment variables**
2. Click **"Add a variable"** and add each of these one by one:

| Key | Value |
|-----|-------|
| `PLAID_CLIENT_ID` | Your Plaid Client ID |
| `PLAID_SECRET` | Your Plaid secret (use Sandbox or Development) |
| `PLAID_ENV` | Set to `sandbox` if testing, leave blank for real banks |
| `SUPABASE_URL` | Your Supabase Project URL |
| `SUPABASE_SERVICE_KEY` | Your Supabase service_role key |

3. Click **Save** after adding all five

---

## Step 4 — Deploy the new code

Your project folder should look like this:
```
budget-tracker/
  public/
    index.html          ← your updated tracker
  netlify/
    functions/
      sync-transactions.js
      create-link-token.js
      exchange-token.js
      get-data.js
      save-data.js
  netlify.toml
  package.json
  supabase-setup.sql    ← only needed for setup, not deployed
```

**If you're using Git + Netlify (recommended):**
1. Push this folder to your GitHub repo
2. Netlify will auto-deploy

**If you're dragging and dropping to Netlify:**
1. Drag the entire `budget-tracker` folder to your Netlify site's deploy drop zone
2. Make sure the publish directory is set to `public`

---

## Step 5 — Connect your bank accounts

1. Open your deployed site
2. Tap **Banks** in the bottom navigation
3. Tap **"Connect a bank account"**
4. A Plaid popup will appear — search for your bank, log in with your normal bank credentials
5. Repeat for each bank account you want to sync
6. Tap **"Sync now"** — your transactions will appear within seconds

---

## How it works after setup

- Every **6 hours**, Netlify automatically pulls new transactions from all your banks
- When you open the app, it loads the latest data instantly
- You still have the **Add** tab to log manual things (cash, splits, etc.)
- Each transaction shows which bank it came from

---

## Troubleshooting

**"Could not load data"** — Check that all 4 environment variables are set in Netlify and redeploy

**"Connection cancelled" when connecting bank** — Make sure Plaid Development access is approved (not just Sandbox)

**Transactions not showing** — Tap "Sync now" in the Banks tab; first sync can take 30 seconds

**Categories look wrong** — The category mapping is in `sync-transactions.js` — you can edit the `mapCategory` function to adjust how Plaid categories map to your categories
