-- Run this entire script in Supabase → SQL Editor → New query

-- Expenses (Plaid-synced + manual)
create table if not exists expenses (
  id bigserial primary key,
  plaid_transaction_id text unique,        -- null for manual entries
  date date not null,
  amt numeric(10,2) not null,
  desc text,
  cat text,
  account_name text,                       -- which bank this came from
  source text default 'manual',            -- 'plaid' or 'manual'
  created_at timestamptz default now()
);

-- Plaid access tokens (one row per connected bank)
create table if not exists plaid_tokens (
  id bigserial primary key,
  item_id text unique not null,
  access_token text not null,
  institution_name text,
  created_at timestamptz default now()
);

-- Budget settings (single row)
create table if not exists budget (
  id int primary key default 1,
  data jsonb not null default '{}'
);

-- Savings log
create table if not exists savings (
  id bigserial primary key,
  month text unique not null,              -- format: YYYY-MM
  amt numeric(10,2) not null,
  created_at timestamptz default now()
);

-- Donations
create table if not exists donations (
  id bigserial primary key,
  date date not null,
  amt numeric(10,2) not null,
  created_at timestamptz default now()
);
